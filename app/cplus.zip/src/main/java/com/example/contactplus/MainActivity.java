package com.example.contactplus;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "ContactPlus";
    private static final int PERMISSIONS_REQUEST_CODE = 100;

    private String[] permissions = new String[] {
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
//            Manifest.permission.BATTERY_STATS,
            Manifest.permission.WAKE_LOCK
    };

    TextView mainTextView;
    ScrollView scrollView;
    Button getContactsButton;
    Button startButton;
    Button stopButton;
    BroadcastReceiver broadcastReceiver;
    ContactPlusApp app;

    @Override
    protected void onStart() {
        super.onStart();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ContactPlusApp.ACTION);

        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, intentFilter);

        refresh();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_about:
                startActivity(new Intent(this, AboutActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void refresh() {
        if (mainTextView != null) {
            Log.d(TAG, "do refresh");
            mainTextView.setText(app.getListStr());
            // Scroll the scroll view to the bottom
            if (scrollView != null) {
                scrollView.post(new Runnable() {
                    @Override
                    public void run() {
                        scrollView.smoothScrollTo(0, mainTextView.getBottom());
                    }
                });
            }
        }
    }

    private int getContactsCount() {
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    boolean checkPermissions() {
        Log.d(TAG, "Check Permissions");
        ArrayList<String> permissionsToRequest = new ArrayList<>();

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
                Log.d(TAG, "Permission denied: " + permission);
            }
        }

        if (permissionsToRequest.isEmpty()) {
            return true;
        } else {
            Log.d(TAG, "Request permissions");

            String[] requestPermissions = new String[permissionsToRequest.size()];
            requestPermissions = permissionsToRequest.toArray(requestPermissions);
            ActivityCompat.requestPermissions(this, requestPermissions, PERMISSIONS_REQUEST_CODE);
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }
            if (allPermissionsGranted) {
                // all permissions granted, do your work
                permissionOk();
            } else {
                // some permissions denied, ask again
                if (checkPermissions()) permissionOk();
            }
        }
    }

    void startBackgroundService() {
        // Create an explicit Intent for the service
        Intent serviceIntent = new Intent(this, ContactsBackgroundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

    void permissionOk() {
        Log.d(TAG, "Permission OK");
        if (app.serviceRunning) {
            startBackgroundService();
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
        } else {
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        }
        getContactsButton.setEnabled(true);
        app.addList("Всего контактов: " + getContactsCount());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        app = (ContactPlusApp) getApplication();
        mainTextView = findViewById(R.id.main_text_view);
        scrollView = findViewById(R.id.scroll_view);
        getContactsButton = findViewById(R.id.get_contacts_button);
        startButton = findViewById(R.id.start_button);
        stopButton = findViewById(R.id.stop_button);

        Context context = this;

        getContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContactsBackgroundService.runJob(app, context);
            }
        });

        Button settingsButton = findViewById(R.id.settings_button);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!app.serviceRunning) {
                    app.setServiceRunning(true);
                    startBackgroundService();
                    startButton.setEnabled(false);
                    stopButton.setEnabled(true);
                    app.addList("Фоновая служба работает");
                    refresh();
                }
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (app.serviceRunning) {
                    app.setServiceRunning(false);
//                    ContactsBackgroundService.isActive = false;
                    stopService(new Intent(MainActivity.this, ContactsBackgroundService.class));
                    stopButton.setEnabled(false);
                    startButton.setEnabled(true);
                    app.addList("Фоновая служба остановлена");
                    refresh();
                }
            }
        });

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // String s = intent.getStringExtra(ContactPlusApp.MESSAGE);
                refresh();
            }
        };

        if (checkPermissions()) {
            permissionOk();
        } else {
            Log.d(TAG, "Permissions NOT OK");
            startButton.setEnabled(false);
            stopButton.setEnabled(false);
            getContactsButton.setEnabled(false);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
    }
}
