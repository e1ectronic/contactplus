package com.example.contactplus;

import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.RemoteException;
import android.provider.ContactsContract;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DownloadContactsTask extends AsyncTask<Void, Void, String> {

    private static final String TAG = "DownloadContactsTask";
    ContactPlusApp app;
    Context context;

    private final OnContactsDownloadedListener listener;

    public DownloadContactsTask(ContactPlusApp theApp, Context theContext, OnContactsDownloadedListener theListener) {
        super();
        app = theApp;
        context = theContext;
        listener = theListener;
    }

    @Override
    protected String doInBackground(Void... voids) {
        try {
            URL url = new URL(app.url());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();
                Log.d(TAG, "received data");
                return response.toString();
            } else {
                Log.d(TAG, "conn not OK: " + conn.getResponseCode());
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "Exception in background");
            return null;
        }
    }


    private static class CallbackAsyncTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result = null;
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                // Get the response code and message from the server
                int responseCode = urlConnection.getResponseCode();
                String responseMessage = urlConnection.getResponseMessage();

                // Check if the response code is in the 200 range to indicate a successful request
                if (responseCode >= HttpURLConnection.HTTP_OK && responseCode < 300) {
                    // Request was successful, log the response message
                    Log.d(TAG, "Response message: " + responseMessage);
                } else {
                    // Request failed, log the response code and message
                    Log.e(TAG, "Request failed with response code " + responseCode + " and message: " + responseMessage);
                }

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                result = readStream(in);

                urlConnection.disconnect();

            } catch (IOException e) {
                Log.e(TAG, "Exception occurred during request: " + e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            // Handle the result here
        }

        private String readStream(InputStream is) throws IOException {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            int i = is.read();
            while(i != -1) {
                bo.write(i);
                i = is.read();
            }
            return bo.toString();
        }
    }


    int addContacts(JSONArray contactsArray) throws RemoteException, OperationApplicationException {
        if (contactsArray == null) return 0;
        ContentResolver content = context.getContentResolver();
        long startTime = System.currentTimeMillis();
        ArrayList<ContentProviderOperation> ops = new ArrayList<>();
        int count = 0, id, maxId = 0;
        for (int i = 0; i < contactsArray.length(); i++) {
            JSONObject contact = contactsArray.optJSONObject(i);
            if (contact == null) continue;
            id = contact.optInt("id", 0);
            if (id > maxId) maxId = id;
            if (addContact(content, ops, contact)) count++;
        }
        if (ops.size() > 0) content.applyBatch(ContactsContract.AUTHORITY, ops);
        app.addList("Добавлено контактов: " + count
                + " за " + (System.currentTimeMillis() - startTime) + " ms");
        if (maxId > 0) checkBack(maxId);
        return count;
    }


    @Override
    protected void onPostExecute(String result) {
        if (result != null) {
            try {
                if (result.startsWith("{")) {  // This is a JSON object, not an array
                    JSONObject jsonObject = new JSONObject(result);
                    String error = jsonObject.optString("error", "").trim();
                    app.addList("Ошибка: " + error);
                    app.setError(error);
                } else {
                    JSONArray tasksArray = new JSONArray(result);  // array of tasks
                    int count = 0;
                    for (int i = 0; i < tasksArray.length(); i++) {
                        JSONObject task = tasksArray.optJSONObject(i);
                        if (task == null) continue;
                        switch (task.optString("task", "")) {
                            case "add":
                                count = addContacts(task.optJSONArray("contacts"));
                                break;
                        }
                    }
                    if (count == 0) app.addList("Нет новых контактов");
                }
            } catch (Exception e) {
                e.printStackTrace();
                app.addList("Ошибка при обработке данных: " + e.getMessage());
            }
        } else {
            app.addList("Ошибка при скачивании данных");
        }
        if (listener != null) {
            listener.onContactsDownloaded();
        }
    }

    void checkBack(int lastId) {
        try {
            app.setLastContactId(lastId);
            CallbackAsyncTask task = new CallbackAsyncTask();
            task.execute(app.url() + "&done=1");
        } catch (Exception e) {
            // Log any exceptions that occurred during the request
            Log.e(TAG, "Exception occurred during request: " + e.getMessage(), e);
        }
    }

    boolean addContact(ContentResolver content, ArrayList<ContentProviderOperation> ops, JSONObject contactObject) {
        String phone = contactObject.optString("phone", "").trim();
        if (!phone.isEmpty()) phone = "+" + phone;

        // Check if phone number already exists in phonebook
        if (checkIfPhoneNumberExists(content, phone)) {
            return false;
        }
        String sourceName = contactObject.optString("name", "").trim();
        if (sourceName.isEmpty()) sourceName = phone;

        String name = sourceName;
        int nameTry = 1;
        while (checkIfNameExists(content, name)) {
            nameTry++;
            name = sourceName + " (" + nameTry + ")";  // Alice (2)
        }

        app.addList(phone + " / " + name);

        String firstName = contactObject.optString("first_name", "").trim();
        String lastName = contactObject.optString("last_name", "").trim();
        String url = contactObject.optString("url", "").trim();
        String notes = contactObject.optString("notes", "").trim();
        String email = contactObject.optString("email", "").trim();
        String org = contactObject.optString("org", "Академия спорта").trim();
        String role = contactObject.optString("role", "Клиент").trim();
        int backReference = ops.size();

        // step 1: id
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.AGGREGATION_MODE, ContactsContract.RawContacts.AGGREGATION_MODE_DISABLED)
                .build()
        );

        // step 2: name
        if (firstName.isEmpty() || lastName.isEmpty()) {  // step by step
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                    .build()
            );
            if (!firstName.isEmpty()) {
            }
            if (!lastName.isEmpty()) {
            }
        } else {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, firstName)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME, lastName)
                    .build()
            );
        }

        // step 3: phone
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                .build()
        );

        // step 4: website
        if (!url.isEmpty()) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Website.TYPE, ContactsContract.CommonDataKinds.Website.TYPE_HOME)
                    .withValue(ContactsContract.CommonDataKinds.Website.URL, url)
                    .build()
            );
        }

        // step 5: email
        if (!email.isEmpty()) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_HOME)
                    .withValue(ContactsContract.CommonDataKinds.Email.DATA, email)
                    .build()
            );
        }

        // note : real name for the contact
        if (!notes.isEmpty()) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Note.NOTE, notes)
                    .build()
            );
        }

        // organization
        if (!org.isEmpty() && !role.isEmpty()) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, backReference)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Organization.COMPANY, org)
                    .withValue(ContactsContract.CommonDataKinds.Organization.TITLE, role)
                    .build()
            );
        }

        return true;
    }


    boolean addContact1(ContentResolver content, JSONObject contactObject) {
        String phone = contactObject.optString("phone", "").trim();
        if (!phone.isEmpty()) phone = "+" + phone;

        // Check if phone number already exists in phonebook
        if (checkIfPhoneNumberExists(content, phone)) {
            return false;
        }
        String sourceName = contactObject.optString("name", "").trim();
        if (sourceName.isEmpty()) sourceName = phone;

        String name = sourceName;
        int nameTry = 1;
        while (checkIfNameExists(content, name)) {
            nameTry++;
            name = sourceName + " (" + nameTry + ")";  // Alice (2)
        }

        app.addList(phone + " / " + name);

        String firstName = contactObject.optString("first_name", "").trim();
        String lastName = contactObject.optString("last_name", "").trim();
        String url = contactObject.optString("url", "").trim();
        String notes = contactObject.optString("notes", "").trim();
        String email = contactObject.optString("email", "").trim();
        String org = contactObject.optString("org", "Академия спорта").trim();
        String role = contactObject.optString("role", "Клиент").trim();

        // step 1: id
        ContentValues values = new ContentValues();
        values.put(ContactsContract.RawContacts.ACCOUNT_TYPE, "");  // link to Google services
        values.put(ContactsContract.RawContacts.ACCOUNT_NAME, "");
        Uri rawContactUri = content.insert(ContactsContract.RawContacts.CONTENT_URI, values);
        long rawContactId = ContentUris.parseId(rawContactUri);

        // step 2: name
        values.clear();
        values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
        values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE);
        values.put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name);
        content.insert(ContactsContract.Data.CONTENT_URI, values);

        // step 2.1: given name
        if (!firstName.isEmpty()) {
            values.clear();
            values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
            values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE);
            values.put(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, firstName);
            content.insert(ContactsContract.Data.CONTENT_URI, values);
        }

        // step 2.2: family name
        if (!lastName.isEmpty()) {
            values.clear();
            values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
            values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE);
            values.put(ContactsContract.CommonDataKinds.StructuredName.FAMILY_NAME, lastName);
            content.insert(ContactsContract.Data.CONTENT_URI, values);
        }

        // step 3: phone
        values.clear();
        values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
        values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
        values.put(ContactsContract.CommonDataKinds.Phone.NUMBER, phone);
        values.put(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
        content.insert(ContactsContract.Data.CONTENT_URI, values);

        // website
        if (!url.isEmpty()) {
            values.clear();
            values.put(ContactsContract.CommonDataKinds.Website.URL, url);
            values.put(ContactsContract.CommonDataKinds.Website.TYPE, ContactsContract.CommonDataKinds.Website.TYPE_HOME);
            values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
            values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE);
            content.insert(ContactsContract.Data.CONTENT_URI, values);
        }

        // email
        if (!email.isEmpty()) {
            values.clear();
            values.put(ContactsContract.CommonDataKinds.Email.DATA, email);
            values.put(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_HOME);
            values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
            values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE);
            content.insert(ContactsContract.Data.CONTENT_URI, values);
        }

        // note : real name for the contact
        if (!notes.isEmpty()) {
            values.clear();
            values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
            values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE);
            values.put(ContactsContract.CommonDataKinds.Note.NOTE, notes);
            content.insert(ContactsContract.Data.CONTENT_URI, values);
        }

        // organization
        if (!org.isEmpty() && !role.isEmpty()) {
            values.clear();
            values.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId);
            values.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE);
            values.put(ContactsContract.CommonDataKinds.Organization.COMPANY, org);  // from folder
            values.put(ContactsContract.CommonDataKinds.Organization.TITLE, role);
            content.insert(ContactsContract.Data.CONTENT_URI, values);
        }

        return true;
    }

    public interface OnContactsDownloadedListener {
        void onContactsDownloaded();
    }

    private boolean checkIfPhoneNumberExists(ContentResolver content, String phoneNumber) {
        if (phoneNumber.isEmpty()) return true;  // empty phone number always exists
        Cursor cursor = content.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                ContactsContract.CommonDataKinds.Phone.NUMBER + "=?",
                new String[]{phoneNumber},
                null);
        boolean exists = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) {
            cursor.close();
        }
        return exists;
    }

    boolean checkIfNameExists(ContentResolver content, String name) {
        Cursor cursor = content.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + "=?",
                new String[] { name },
                null);
        boolean exists = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) {
            cursor.close();
        }
        return exists;
    }
}
